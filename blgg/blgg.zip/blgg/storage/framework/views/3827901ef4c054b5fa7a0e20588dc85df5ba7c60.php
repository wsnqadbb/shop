<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="<?php echo e($v->id); ?>">
        <td><?php echo e($v->id); ?></td>
        <td class="change" column="name" value="<?php echo e($v->name); ?>"><?php echo e($v->name); ?></td>
        <td><?php echo e($v->c_name); ?></td>
        <td><?php echo e($v->desc); ?></td>
        <td>
            <?php if($v->is_hot==1){ ?>
            <input type="button"  value="√" id="<?php echo e($v->id); ?>" class="is_hot">
            <?php }else if($v->is_hot==2){ ?>
            <input type="button"  value="×"  id="<?php echo e($v->id); ?>" class="is_hot">
            <?php } ?>
        </td>
        <td>
            <?php if($v->is_show==1){ ?>
            <input type="button"  value="√" id="<?php echo e($v->id); ?>" class="is_show">
            <?php }else if($v->is_show==2){ ?>
            <input type="button"  value="×"  id="<?php echo e($v->id); ?>" class="is_show">
            <?php } ?>
        </td>
        <td>
            <a href="update?id=<?php echo e($v->id); ?>">修改</a>
            <a href="javascript:;" name="del"   id="<?php echo e($v->id); ?>">删除</a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td colspan="7"><div id="page"><?php echo e($arr->links()); ?></div></td>
</tr>
<script>
    $("[name='del']").click(function(){
        var _this=$(this);
        var goods_id=_this.attr('id');
        if(confirm('是否删除？')){
            $.post('delete',{id:goods_id},function(res){
                if(res==1){
                    _this.parents('tr').remove();
                    alert('删除成功');
                }else{
                    alert('删除失败');
                }
            });
        }
    });
</script>