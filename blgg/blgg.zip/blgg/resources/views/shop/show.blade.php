<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery-3.1.1.min.js"></script>
    <style>
        #page ul li{
            list-style: none;
            float: left;
            padding: 0 15px;
        }
    </style>
</head>
<body>
<select name="is_show" style="margin:0 20px">
    <option value="0">请选择</option>
    <option value="1">上架中</option>
    <option value="2">已下架</option>
</select>
<select name="is_hot" style="margin:0 20px">
    <option value="0">请选择</option>
    <option value="1">热卖中</option>
    <option value="2">淡季中</option>
</select>
<input type="button" name="search" value="搜索" style="margin:0 20px">
<form class="add_form">
    <table border="1">
       <thead>
        <tr>
            <td>商品id</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否热卖</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
       </thead>
        <tbody>
        <?php foreach($arr as $k=>$v){?>
        <tr id="{{$v->id}}">
            <td>{{$v->id}}</td>
            <td class="change" column="name" value="{{$v->name}}">{{$v->name}}</td>
            <td>{{$v->c_name}}</td>
            <td>{{$v->desc}}</td>
            <td>
                <?php if($v->is_hot==1){ ?>
                <input type="button"  value="√" id="{{$v->id}}" class="is_hot">
                <?php }else if($v->is_hot==2){ ?>
                <input type="button"  value="×"  id="{{$v->id}}" class="is_hot">
                <?php } ?>
            </td>
            <td>
                <?php if($v->is_show==1){ ?>
                <input type="button"  value="√" id="{{$v->id}}" class="is_show">
                <?php }else if($v->is_show==2){ ?>
                <input type="button"  value="×"  id="{{$v->id}}" class="is_show">
                <?php } ?>
            </td>
            <td> <a href="update?id={{$v->id}}">修改</a>
                <a href="javascript:;" name="del" id="{{$v->id}}">删除</a></td>
        </tr>
        <?php }?>
        <tr>
            <td colspan="7">
            <div id="page">{{$arr->links()}}</div>
            </td>
        </tr>
        </tbody>
    </table>
</form>
</body>
</html>
<script src="/js/jquery-3.1.1.min.js"></script>
<script>
    $(function(){
        $("[name='del']").click(function(){
            var _this=$(this);
            var goods_id=_this.attr('id');
            console.log(goods_id);''
            if(confirm('是否删除？')){
                $.post('delete',{id:goods_id},function(res){
                    if(res==1){
                        alert('删除成功');
                        _this.parents('tr').remove();
                    }else{
                        alert('删除失败');
                    }
                });
            }
        });
    });
    $('.is_hot').click(function(){
        var str=$(this).val();
        // console.log(str);
        var obj=$(this);
        var id=$(this).attr('id');
        // console.log(id);
        $.ajax({
            method: "POST",
            url: "uphot",
            data: 'is_hot='+str+'&id='+id,
        }).done(function( msg ) {
            console.log(msg);
            if(msg==1){
                if(str=='√'){
                    obj.val('×');
                }else if(str=='×'){
                    obj.val('√');
                }
            }

        });
    });
    $('.is_show').click(function(){
        var str=$(this).val();
        // console.log(str);
        var obj=$(this);
        var id=$(this).attr('id');
        // console.log(id);
        $.ajax({
            method: "POST",
            url: "upshow",
            data: 'is_show='+str+'&id='+id,
        }).done(function( msg ) {
            console.log(msg);
            if(msg==1){
                if(str=='√'){
                    obj.val('×');
                }else if(str=='×'){
                    obj.val('√');
                }
            }
        });
    });
    //搜索
    $("[name='search']").click(function(){
        var is_show=$("[name='is_show']").val();
        // console.log(is_show);
        var is_hot=$("[name='is_hot']").val();
        ajax_show(is_show,is_hot);
    });
    //ajax替换
    function ajax_show(is_show,is_hot){
        $.post('show',{is_show:is_show,is_hot:is_hot},function(res){
            $("tbody").empty();
            $("tbody").html(res);
        });
    }
    //即点即改
    $(document).on('click','.change',function(){
        var _this=$(this);
        var value=_this.attr('value');
        _this.empty();
        _this.html("<input type='text' style='width:200px;' autofocus='autofocus' class='input_change' value="+value+">");
    });
    $(document).on('blur','.input_change',function(){
        var _this=$(this);
        var td=_this.parent();
        var goods_id=_this.parents('tr').attr('id');
        // console.log(goods_id);
        var value=_this.val();
        // console.log(value);
        var column=td.attr('column');
        // console.log(column);
        $.post('change',{value:value,column:column,goods_id:goods_id},function(res){
            _this.parent().text(value);
            if(res==1){
                alert('修改名称成功');
            }else{
                alert('修改失败');
            }
        });
    });

</script>