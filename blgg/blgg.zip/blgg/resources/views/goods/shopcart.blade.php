<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="layui/css/layui.css">
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
</head>
<body id="loadingPicBlock" class="g-acc-bg">
    <input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
    <div>
        <!--首页头部-->
        <div class="m-block-header">
            <a href="/" class="m-public-icon m-1yyg-icon"></a>
            <a href="/" class="m-index-icon">编辑</a>
        </div>
        <!--首页头部 end-->
        <div class="g-Cart-list">
            <ul id="cartBody">
                @foreach($data as $v)
                <li id="u-Cart-r">
                    <s class="xuan current" cart_id="{{$v->cart_id}}"></s>
                    <a class="fl u-Cart-img" goods_id="{{$v->goods_id}}" href="/v44/product/12501977.do">
                        <img src="images/220962.jpg" border="0" alt="">
                    </a>
                    <div class="u-Cart-r">
                        <a href="/v44/product/12501977.do" class="gray6">{{$v->goods_name}}</a>
                        <span class="gray9">
                            <em>价值：￥{{$v->goods_price}}</em>
                        </span>
                        <div class="num-opt">
                            <em class="num-mius dis min"><i></i></em>
                            <input class="text_box" name="num" maxlength="6" cart_id="{{$v->cart_id}}"  price="{{$v->goods_price}}" type="text" value="{{$v->number}}"  goods_num="{{$v->goods_pnum}}" codeid="12501977">
                            <em class="num-add add"><i></i></em>
                        </div>
                        <a href="javascript:;" name="delLink" cid="12501977" isover="0" class="z-del" cart_id="{{$v->cart_id}}"><s></s></a>
                    </div>
                </li>
                @endforeach
            </ul>
            <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
        </div>
        <div id="mycartpay" class="g-Total-bt g-car-new" style="">
            <dl>
                <dt class="gray6">
                    <s class="quanxuan current"></s>全选
                    <p class="money-total">合计<em class="orange total"><span>￥</span>17.00</em></p>

                </dt>
                <dd>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account remove" name="remove">删除</a>
                    <a href="javascript:;" id="b_payment" class="orangeBtn w_account">去结算</a>
                </dd>
            </dl>
        </div>
        <div class="hot-recom">
            <div class="title thin-bor-top gray6">
                <span><b class="z-set"></b>人气推荐</span>
                <em></em>
            </div>
            <div class="goods-wrap thin-bor-top">
                <ul class="goods-list clearfix">
                    @foreach($goods_info as $k=>$v)
                        <li>
                            <a href="shopContent?goods_id={{$v->goods_id}}" class="g-pic">
                                <img src=images/220962.jpg width="136" height="136">
                            </a>
                            <p class="g-name">
                                <a href="https://m.1yyg.com/v44/products/23458.do">{{$v->goods_name}}</a>
                            </p>
                            <ins class="gray9">价值:￥{{$v->goods_price}}</ins>
                            <div class="btn-wrap">
                                <div class="Progress-bar">
                                    <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                                    </p>
                                </div>
                                <div class="gRate" data-productid="23458">
                                    <a href="javascript:;"><s></s></a>
                                </div>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>




<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="index" ><i></i>潮购</a></li>
        <li class="f_announced"><a href="allshops" class="hover"><i></i>全部商品</a></li>
        <li class="f_single"><a href="willshow" ><i></i>最新揭晓</a></li>
        <li class="f_car"><a id="btnCart" href="shopcart" ><i></i>购物车</a></li>
        <li class="f_personal"><a href="userpage" ><i></i>我的潮购</a></li>
    </ul>
</div>

<script src="js/jquery-1.11.2.min.js"></script>
    <script>

    // 全选
    $(".quanxuan").click(function () {
        if($(this).hasClass('current')){
            $(this).removeClass('current');

             $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    $(this).removeClass("current");
                } else {
                    $(this).addClass("current");
                }
            });
            GetCount();
        }else{
            $(this).addClass('current');

             $(".g-Cart-list .xuan").each(function () {
                $(this).addClass("current");
                // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
            });
            GetCount();
        }


    });
    // 单选
    $(".g-Cart-list .xuan").click(function () {
        if($(this).hasClass('current')){


            $(this).removeClass('current');

        }else{
            $(this).addClass('current');
        }
        if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');

            }else{
                $('.quanxuan').removeClass('current');
            }
        // $("#total2").html() = GetCount($(this));
        GetCount();
        //alert(conts);
    });
  // 已选中的总额
    function GetCount() {
        var conts = 0;
        var aa = 0;
        $(".g-Cart-list .xuan").each(function () {
            if ($(this).hasClass("current")) {
                for (var i = 0; i < $(this).length; i++) {
                    conts += parseInt($(this).parents('li').find('input.text_box').val()*$(this).parents('li').find('input.text_box').attr('price'));
                    // aa += 1;
                }
            }
        });

         $(".total").html('<span>￥</span>'+(conts).toFixed(2));
    }
    GetCount();
    //商品加减算总数
    $(".add").click(function () {
        var t = $(this).prev();
        var num= t.attr('goods_num');
        t.val(parseInt(t.val()) + 1);
        if(t.val()<=parseInt(num)){
            GetCount();
            var cart_id= t.attr('cart_id');
            change_num(t.val(),cart_id);
        }else{
            alert('已达最大库存！');
            t.val(parseInt(num));
        }
    });
    $(".min").click(function () {
        var t = $(this).next();
        if(t.val()>1){
            t.val(parseInt(t.val()) - 1);
            GetCount();
            var cart_id= t.attr('cart_id');
            change_num(t.val(),cart_id);
        }
    });
    //商品数量失焦
    $(document).on('blur','.text_box',function(){
        var _this=$(this);
        var num=parseInt(_this.val());
        var goods_num= _this.attr('goods_num');
        if(goods_num==0){
            _this.val(0);
            alert('该商品没有库存');
        }

        if( isNaN(num) ){
            _this.val(1);
        }

        if(num<goods_num){
            _this.val(num);
        }

        if(num>goods_num){
            _this.val(goods_num);
        }

        if(num<=1){
            _this.val(1);
        }

        var cart_id= _this.attr('cart_id');
        change_num(num,cart_id);

    });

    function change_num(num,cart_id){
        var data={};
        data.num=num;
        data.cart_id=cart_id;
        $.post('updateNum',data,function(res){

        });
    }
</script>
<script src="layui/layui.js"></script>
<script src="layui/layui.js"></script>
        <script>
            $(function(){
                layui.use('layer',function(){
                    var layer=layui.layer;
                    //单删
                    $(document).on('click','.z-del',function(){
                        var _this=$(this);
                        var cart_id=_this.attr('cart_id');
                        var data=[];
                        data.push(cart_id);
                        if(cart_del(data)){
                            $(this).parents('li').remove();
                            GetCount();
                        }
                    });
                    //多删
                    $(document).on('click','#a_payment',function(){
                        $(this).css('background','#fff');
                        var data=[];
                        $(".g-Cart-list .xuan").each(function () {
                            if ($(this).hasClass("current")) {
                                var cart_id=$(this).attr('cart_id');
                                data.push(cart_id);
                            }
                        });
                        // console.log(data);
                        // return false;
                        if(cart_del(data)){
                            $(".g-Cart-list .xuan").each(function () {
                                if ($(this).hasClass("current")) {
                                    $(this).parents('li').remove();
                                }
                            });
                        }
                        GetCount();
                    });
                    //购物车删除
                    function cart_del(data){
                        var flag=false;
                        var url="cart_del";
                        $.ajax({
                            url:url,
                            type:'post',
                            data:{data},
                            dataType:'json',
                            async:false,
                            success:function(res){
                                if(res.code==1){
                                    layer.msg(res.msg);
                                    flag=true;
                                }else{
                                    layer.msg(res.msg);
                                }
                            }
                        });
                        return flag;
                    }
                     //结算
                     $(document).on('click','#b_payment',function(){
                        $(this).css('background','#f22f2f');
                        var data=[];
                        $(".g-Cart-list .xuan").each(function () {
                            if ($(this).hasClass("current")) {
                                // var cart_id=;
                                data.push($(this).attr('cart_id'));
                            }
                        });
                        // console.log(data);
                        // return false;
                        if(order(data)){
                            $(".g-Cart-list .xuan").each(function () {
                                if ($(this).hasClass("current")) {
                                    $(this).parents('li').remove();
                                }
                            });
                        }
                        GetCount();
                    });
                    function order(data){
                        var flag=false;
                        var url="order";
                        $.ajax({
                            url:url,
                            type:'post',
                            data:{data:data},
                            dataType:'json',
                            async:false,
                            success:function(res){
                                // console.log(11111);
                                if(res.code==1){
                                    layer.msg(res.msg);
                                    flag=true;
                                    window.location.href="/payment?order_id="+res.order_id;
                                }else if(res.code==0){
                                    layer.msg(res.msg);
                                }
                            }
                        });
                        return flag;
                    }
                });
            });
        </script>
</body>
</html>