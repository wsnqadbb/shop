<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/**
 * 基本路由
 */
Route::get('/', function () {
    return view('welcome');
});
Route::get('hello', function () {
    return 'hello,welcome to LarvelAcademy .org';
});
/**
 * 路由映射控制器
 */
Route::get('user','user\UserController@show');
//Route::match(['get', 'post'], 'foo', function () {
//    return 'This is a request from get or post';
//});
//
//Route::any('bar', function () {
//    return 'This is a request from any HTTP verb';
//});
/**
 * 路由加判断，重定向百度
 */
Route::get('user/{id}',function ($id){
        if($id<10){
            return redirect('http://www.baidu.com');
        }else{
            return view('usercontroller');
        }
});
/**
 * 路由器前缀
 */
Route::prefix('admin')->group(function () {
    Route::get('user', function () {
            return redirect('http://www.baidu.com');
        });
    Route::get('name','user\UserController@show');
    Route::get('add','user\UserController@add');
    Route::get('look','user\UserController@look');
    Route::get('orm','user\UserController@orm');
});

//Route::get('add','shop\ShopController@add');
//Route::post('doadd','shop\ShopController@doadd');
//Route::any('show','shop\ShopController@show');
//Route::post('delete','shop\ShopController@delete');
//Route::get('update','shop\ShopController@update');
//Route::post('update_do','shop\ShopController@update_do');
//Route::post('uphot','shop\ShopController@uphot');
//Route::post('upshow','shop\ShopController@upshow');
//Route::post('change','shop\ShopController@change');
//海淘-电商
Route::get('index','index\IndexController@index');
Route::get('userpage','index\IndexController@userpage')->middleware("test");;
Route::get('set','index\IndexController@set');
Route::get('userprofile','index\IndexController@userprofile');
Route::get('register','index\RegisterController@register');
Route::post('register_do','index\RegisterController@register_do');
Route::get('login','index\RegisterController@login');
Route::post('login_do','index\RegisterController@login_do');
Route::get('show','goods\GoodsController@show');
Route::post('send','index\RegisterController@send');
Route::get('page','index\IndexController@page');
//所有商品展示
Route::get('allshops','index\IndexController@allshops');
//最新揭晓
Route::get('willshow','index\IndexController@willshow');
//购物车
//Route::get('shopcart','index\IndexController@shopcart');
//商品详情
Route::get('detail','goods\GoodsController@detail');
//条数
Route::get('shopCount','index\IndexController@shopCount');
//购物车
Route::get('shopcart','goods\GoodsController@shopcart');

Route::get('user','UsersController@index');
Route::post('docart','goods\GoodsController@docart');

Route::get('shopcontent','goods\GoodsController@shopcontent');
Route::post('cart_del','goods\GoodsController@cart_del');
Route::post('updateNum','goods\GoodsController@updateNum');
Route::get('payment','goods\GoodsController@payment');

Route::post('order','goods\GoodsController@order');

Route::post('order_do','goods\GoodsController@order_do');
Route::get('address','goods\GoodsController@address');


Route::post('address_do','goods\GoodsController@address_do');

Route::get('writeaddr','goods\GoodsController@writeaddr');

Route::any('add_del','goods\GoodsController@add_del');


Route::get('address_update','goods\GoodsController@address_update');


Route::get('add_upadte','goods\GoodsController@add_upadte');

Route::post('add_update_do','goods\GoodsController@add_update_do');