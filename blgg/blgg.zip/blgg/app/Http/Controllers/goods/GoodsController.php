<?php

namespace App\Http\Controllers\goods;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\models\CartModel;
use App\models\OrderModel;
class GoodsController extends Controller
{
    /**
     * 商品详情
     */
   public function detail(Request $request){
       $goods_id=$request->input('goods_id');
       $arr=DB::table('goods')->where('goods_id',$goods_id)->get();
        return view('goods.shopcontent',['arr'=>$arr]);
   }

    /**
     * 商品分类的信息
     * @param Request $request
     */
   public function content(Request $request){

   }
/*
   public function docart(Request $request)
    {
    $goods_id=$request->input('id');
    $arr=DB::table('goods')->where('goods_id',$goods_id)->first();
    if($arr){
        $id=$request->session()->get('u_id');
            if(session($id)){
                echo json_encode([
                    'msg'=>1,
                    'font'=>'请您先登录'
                ]);
            }else{
                $goods_up=$arr->goods_up;
                    if($goods_up!=1){
                        echo json_encode([
                            'msg'=>1,
                            'font'=>'没有此商品'
                        ]);
            }else{
               $where=[
                'goods_id'=>$goods_id,
                'user_id'=>$id
               ];
               $cart=DB::table('cart')->where($where)->first();
                 if($cart){
                    $number=$cart->number;
                    $num=$number+1;
                    $goods_pnum=$arr->goods_pnum;
                    if($num>$goods_pnum){
                        echo json_encode([
                            'msg'=>1,
                            'font'=>'库存不足'
                        ]);
                    }else{
                        $cart=DB::table('cart')->where($where)->update(['number'=>$num]);
                         echo json_encode([
                            'msg'=>0,
                            'font'=>'添加成功'                
                         ]);

                    }
                 }else{
                    $data=[];
                    $data['goods_id']=$goods_id;     
                    $data['user_id']=$id;      
                    $data['number']=1;
                    $data['ctime']=time();
                    DB::table('cart')->insert($data);
                    echo json_encode([
                        'msg'=>0,
                        'font'=>'添加成功'

                    ]);
                 }

            }
        }
    }else{
        echo json_encode([
            'msg'=>1,
            'font'=>'没有该商品'
        ]);
    }

}
*/

public function docart(Request $request)
   {
    $goods_id=$request->input('id');
   // print_r($arr);
   $arr=DB::table('goods')->where('goods_id',$goods_id)->first();
   if($arr){
    $id = $request->session()->get('u_id');
    if(session($id)){
        echo json_encode([
            'msg'=>1,
            'font'=>'您没有登录'
        ]);
    }else{
        $goods_up=$arr->goods_up;
        if($goods_up!=1){
            echo json_encode([
                'msg'=>1,
                'font'=>'没有此商品'
            ]);
        }else{
            $where=[
                'goods_id'=>$goods_id,
                'user_id'=>$id
            ];
            $cart= DB::table('cart')->where($where)->first();
            if($cart){
                $number=$cart->number;
                $num=$number+1;
                $goods_pnum=$arr->goods_pnum;
                if($num>$goods_pnum){
                    echo json_encode([
                        'msg'=>1,
                        'font'=>'库存不足'
                    ]);
                }else{
                    $cart= DB::table('cart')->where($where)->update(['number'=>$num]);
                    echo json_encode([
                        'msg'=>0,
                        'font'=>'添加成功'
                    ]);
                }
            }else{
                $data=[];
                $data['goods_id']=$goods_id;
                $data['user_id']=$id;
                $data['number']=1;
                $data['ctime']=time();
                DB::table('cart')->insert($data);
                echo json_encode([
                    'msg'=>0,
                    'font'=>'添加成功'
                ]);
            }
           
        }
    }
}else{
    echo json_encode([
        'msg'=>1,
        'font'=>'没有该商品'
         ]);
    }
}

public function shopcart(){
    $user_id=session('u_id');
    if(empty($user_id)){
        echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
    }
    $data=DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where('status',1)->select("*")->get();
    $goods_info=DB::table('goods')->where('goods_hot',1)->limit(4)->select('goods_img','goods_price','goods_name','goods_id')->get();
    return view('goods.shopcart',['data'=>$data,'goods_info'=>$goods_info]);
}

/**
 * 购物车的删除
 * @param Request $request
 */
public function cart_del(Request $request){
        $data=$request->input('data');
//            print_r($data);
        if(!empty($data)){
            foreach($data as $k=>$v){
                $res=DB::table('cart')->where(['cart_id'=>$v])->update(['status'=>2]);
            }
            if($res){
                echo json_encode(['code'=>1,'msg'=>'删除成功！']);
            }else{
                echo json_encode(['code'=>1,'msg'=>'删除失败！']);
            }
        }else{
            echo json_encode(['code'=>0,'msg'=>'请选择商品！']);
        }
}

/**
 * 加减改变商品数量
 * @param Request $request
 */
public function updateNum(Request $request){
    $data=$request->input();
    $cart_id=$data['cart_id'];
    $num=$data['num'];
    $res=DB::table('cart')->where('cart_id','=',$cart_id)->update(['number'=>$num]);
}



public function order(Request $request){
    // echo 2345;die;
$userid=$request->session()->get('u_id');
if(empty($userid)){
    echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
}
// echo 2345;die;
$data=$request->input('data');
// print_r($data);
// die;
if(!empty($data)){
        $cart=CartModel::whereIn('cart_id',$data)->join('goods','goods.goods_id','=','cart.goods_id')->select('*')->get()->toArray();//根据传过来的数据进行查询
//print_r($cart);die;
        foreach($cart as $k=>$v){
        if($v['number']>$v['goods_pnum']){
            $all[]=$v['goods_name'];
    }
    $goodsIds[]=$v['goods_id'];
}
if(!empty($all)){
echo json_encode(['code'=>0,'msg'=>implode(',',$arr).'商品库存不足,请减少一些数量']);
}
foreach($cart as $k=>$v){
    if($v['goods_show']!=1){
        $add[]=$v['goods_name'];
}
    $money[]=$v['goods_price']*$v['number'];
}
if(!empty($add)){
echo json_encode(['code'=>0,'msg'=>'卖完了,'.implode(',',$add).'----这些商品下架了,您去别的地方买去吧']);
    }
}else{
    echo json_encode(['code'=>0,'msg'=>'愣着干嘛,选商品啊']);
}
$order_sn=date("YmdHis",time()).rand(1000,9999);//货号
DB::table('cart')->whereIn('cart_id',$data)->get();
foreach($cart as $k=>$v){
$array=[
    'order_no'=>$order_sn,
    'u_id'=>$userid,
    'order_status'=>1,
    'order_amount'=>array_sum($money),
    'ctime'=>time(),
    'pay_status'=>1,
    'order_pay_type'=>1,
    'goods_name'=>$v['goods_name'], 
    'shop_price'=>$v['goods_price'],
    'pay_id'=>1,
];
}
$res=DB::table('order')->insertGetId($array);
if(!empty($res)){
    DB::table('cart')->whereIn('cart_id',$data)->update(['status'=>0]);
foreach($cart as $k=>$v){
$arr=[
    'order_id'=>$res,
    'goods_id'=>$v['goods_id'],
    'goods_name'=>$v['goods_name'], 
    'order_amount'=>array_sum($money),
    'order_no'=>$order_sn,
    'u_id'=>$userid,
    'buy_num'=>$v['number'],
    'shop_price'=>$v['goods_price'],
    ];
  }
  $arr=DB::table('order_detail')->insert($arr);
    echo json_encode(['code'=>1,'msg'=>'添加成功','order_id'=>$res]);
    }else{
        echo json_encode(['code'=>0,'msg'=>'添加失败','order_id'=>'']);
    }
}


public function order_do(Request $request){

  //  print_r($data); die;
  $userid=$userid=$request->session()->get('u_id');
  if(empty($userid)){
      echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
  }
 $id=$request->input('order_id');

$where=[
    'u_id'=>$userid,
    'order_id'=>$id,
];
    $arr=DB::table('order_address')->where($where)->first();
   // print_r($arr);die;
if(empty($arr)){
    echo json_encode(['code'=>0,'msg'=>'请填写收货地址','order_id'=>$id]);
}else{

    echo json_encode(['code'=>1,'msg'=>'准备支付']);
}




}


public function payment(Request $request){
    $order_id=$request->input();
    // dump($order_id);die;
    $user_id=$user_id=$request->session()->get('u_id');
    $where=[
        'order_id'=>$order_id,
        'u_id'=>$user_id
    ];
    
    $arr=DB::table('order')->where($where)->get()->toArray();
   // print_r($order_id);die;
//       dump($arr);
    $order_price=DB::table('order_detail')->where($where)->get()->toArray()[0];
//       dump($order_price);die;
    return view("goods.payment",['arr'=>$arr,'order_price'=>$order_price]);
  
}

public function address(Request $request){
    $order_id=$request->input('order_id');
    $user_id=$user_id=$request->session()->get('u_id');
    //       print_r($user_id);die;
           if(empty($user_id)){
               echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
           }
    $arr=DB::table('order_address')->join('user','user.u_id','=','order_address.u_id')->where('order_address.u_id',$user_id)->where('is_del',0)->get();
    return view("goods.address",['order_id'=>$order_id,'arr'=>$arr]);

}

public function address_do(Request $request){
    $data=$request->input();
//        dump($data);die;
    $user_id=$user_id=$request->session()->get('u_id');
    if(empty($user_id)){
        echo "<script>alert('请先登录！');location.href='login?href='+location.href</script>";die;
    }
    $data['u_id']=$user_id;
    $data['is_del']=0;
    $res=DB::table('order_address')->insert($data);
    if($res){
        echo json_encode(['code'=>1,'msg'=>'添加成功']);
    }else{
        echo json_encode(['code'=>0,'msg'=>'添加失败']);
    }
}

public function writeaddr(Request $request){
    $order_id=$request->input('order_id');
    return view('goods.writeaddr',['order_id'=>$order_id]);
 }

 public function  add_del(Request $request){
    $address_id=$request->input('address_id');
    $all=DB::table('order_address')->where('address_id',$address_id)->get()->toArray()[0];
//        dump($all);die;
    if($all->is_default==1){
        return json_encode([
            'code'=>0,
            'msg'=>'请先修改默认地址，再次删除'
        ]);
    }
    $res=DB::table('order_address')->where('address_id',$address_id)->update(['is_del'=>1]);
    if($res){
        return json_encode([
            'code'=>1,
            'msg'=>'删除成功'
        ]);
    }else{
        return json_encode([
            'code'=>0,
            'msg'=>'删除失败'
        ]);
    }
}
public function add_update(Request $request){
    $address_id=$request->input('address_id');
  //  dump($address_id);
    $user_id = $user_id = $request->session()->get('u_id');
    
    $res=DB::table('order_address')->where('address_id','!=',$address_id)->where('user_id',$user_id)->update(['is_default'=>0]);
    $add=DB::table('order_address')->where('address_id','=',$address_id)->where('user_id',$user_id)->update(['is_default'=>1]);
}
//编辑修改
public function address_update(Request $request){
    $address_id=$request->input('address_id');
//        dump($address_id);
    $address=DB::table('order_address')->where('address_id',$address_id)->get()->toArray();
//        dump($address);die;
    return view("goods.address_update",['address'=>$address]);
}
//编辑修改执行
public function add_update_do(Request $request){
    $data=$request->input('data');
//        dump($data);die;
    $res=DB::table('order_address')->where('address_id',$data['address_id'])->update($data);
    if($res){
        return json_encode([
            'code'=>1,
            'msg'=>'保存成功'
        ]);
    }else{
        return json_encode([
            'code'=>0,
            'msg'=>'保存失败'
        ]);
    }
}









}