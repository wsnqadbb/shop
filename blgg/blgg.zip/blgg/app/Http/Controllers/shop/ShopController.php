<?php

namespace App\Http\Controllers\shop;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ShopController extends Controller
{
    /**
     * 添加页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function add(){
        //查询
        $arr=DB::table('cate')->get();
//        print_r($arr);
//        exit;
        return view('shop.add',['cate'=>$arr]);
    }

    /**
     * 添加执行页面
     */
    public function doadd(Request $request){
     $data=$request->input();
    $insert_data['name']=rtrim($data['name']);
    $insert_data['c_id']=intval($data['c_id']);
    $insert_data['desc']=rtrim($data['desc']);
    $insert_data['is_hot']=intval($data['is_hot']);
    $insert_data['is_show']=intval($data['is_show']);
     $res=DB::table('shop')->insert($insert_data);
     if($res){
       echo 1;
     }else{
        echo  2;
     }
    }

    /**
     * 展示页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function show(Request $request){
        $is_show=$request->input('is_show');
        $is_hot=$request->input('is_hot');
        $where=[];
        if(!empty($is_show)&&empty($is_hot)){
            $where['is_show']=$is_show;
        }elseif (!empty($is_hot)&&empty($is_show)){
            $where['is_hot']=$is_hot;
        }elseif (!empty($is_hot)&&!empty($is_show)){
            $where['is_show']=$is_show;
            $where['is_hot']=$is_hot;
        }
        $arr=DB::table('shop')->where($where)->join('cate','cate.c_id','=','shop.c_id')->paginate(5);
//        print_r($arr);exit;
//        foreach($arr as $k=>$v){
//            if($v->is_hot==1){
//                $arr[$k]->is_hot='√';
//            }else{
//                $arr[$k]->is_hot='×';
//            }
//        }
        if($request->ajax()&&$request->post()){
            return view('shop.ajax_show',['arr'=>$arr]);
        }else{
            return view('shop.show',['arr'=>$arr]);
        }
    }

    /**
     * 删除
     * @param Request $request
     * @return int
     */
    public function delete(Request $request){
        $goods_id=$request->input('id');
        $res=DB::table('shop')->where('id',$goods_id)->delete();
        if($res){
            return 1;
        }else{
            return 2;
        }
    }

    /**
     * 修改展示页面
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    public function update(Request $request){
        $cate_info=DB::table('cate')->get();
        $id=$request->input('id');
        $arr=DB::table('shop')->where('id',$id)->first();
        return view('shop.update',['arr'=>$arr,'cate'=>$cate_info]);
    }
    public function update_do(Request $request){
        $data=$request->input();
        $id=$data['id'];
        $res=DB::table('shop')->where('id',$id)->update($data);
        if($res){
            return 1;
        }else{
            return 2;
        }
    }
    public function uphot(Request $request){
        $is_hot=$request->input('is_hot');
//         echo $is_hot;
        $id=$request->input('id');
//         echo $id;
        if($is_hot=='√'){
            $res=DB::table('shop')->where('id',$id)->update(['is_hot'=>2]);
        }else if($is_hot=='×'){
            $res=DB::table('shop')->where('id',$id)->update(['is_hot'=>1]);
        }
        if($res){
            echo  1;
        }
    }
    public function upshow(Request $request){
        $is_hot=$request->input('is_show');
//         echo $is_hot;
        $id=$request->input('id');
//         echo $id;
        if($is_hot=='√'){
            $res=DB::table('shop')->where('id',$id)->update(['is_show'=>2]);
        }else if($is_hot=='×'){
            $res=DB::table('shop')->where('id',$id)->update(['is_show'=>1]);
        }
        if($res){
            echo  1;
        }
    }
    //即点即改
    public function change(Request $request){
        $column=$request->input('column');
//        print_r($column);exit;
        $goods_id=$request->input('goods_id');
//        print_r($goods_id);exit;
        $value=$request->input('value');
//        print_r($value);exit;
        $res=DB::table('shop')->where('id',$goods_id)->update(["$column"=>"$value"]);
//        echo $res;exit;
        if($res){
            return 1;
        }else{
            return 2;
        }
    }
}
