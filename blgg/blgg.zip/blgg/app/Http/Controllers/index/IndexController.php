<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
class IndexController extends Controller
{
    public static $arrCate=[];
    //潮购主页
    public function index(Request $request){
        $num=6;
        $arr=DB::table('goods')->where('goods_show',1)->where('is_like',1)->paginate($num);
        if($request->ajax()){
            return view('index.ajaxIndex',['arr'=>$arr]);
        }else{
            $count=DB::table('goods')->where('goods_show',1)->count();
            $page=ceil($count/6);
            $data=DB::table('goods')->where(['goods_show'=>1,'is_tell'=>1])->paginate(2);
            return view('index.index',['arr'=>$arr,'data'=>$data,'page'=>$page]);
        }
    }
    //我的潮购
    public function userpage(){
        return view('index.userpage');
    }
    //潮购记录
    public function userprofile(){
        return view('index.userprofile');
    }
    //设置页面
    public function set(){
        return view('index.set');
    }
    //所有商品
    public function allshops(Request $request){
        $num=6;
        //获取分类id
        $cate_id=$request->input('cate_id');
//        echo $cate_id;die;
        if(!empty($cate_id)){
            $arrIds=DB::table('category')->select('cate_id')->where('pid',0)->get();
            $this->get($cate_id);
        }
       $cate_id=self::$arrCate;
        //获取搜索信息
        $search=$request->input('search','');
        $where=[
            'goods_show'=>1
        ];
        //点击排序
        $order=$request->input('order','goods_id');
        $order_type=$request->input('order_type','asc');
        if($order=='goods_hot'||$order=='goods_new'){
            $where[$order]=1;
        }
        if(!empty($cate_id)){
            //查询分类下的商品
            $goods_info=DB::table('goods')->where($where)
                ->whereIn('cate_id',$cate_id)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->paginate($num);

        }else{
            //查询所有商品
            $goods_info=DB::table('goods')->where($where)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->paginate($num);
        }
//        echo 111;die;
        if($request->ajax()){
            return view('index.ajaxGoods',['goods_info'=>$goods_info]);
        }else{
            $cate_info=DB::table('category')->where('pid',0)->get();
            return view('index.allshops',['cate_info'=>$cate_info,'goods_info'=>$goods_info]);
        }
    }
    /**
     * 获取分类的id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\think\response\View
     */
    private  function get($id){
            $arrIds=DB::table('category')->select('cate_id')->where('pid',$id)->get();
            if(count($arrIds)!=0){
                foreach($arrIds as $k=>$v){
                    $cateId=$v->cate_id;
                    $arrNews=$this->get($cateId);
                }
            }
            foreach($arrIds as $v){
                $cate_id=$v->cate_id;
                array_push(self::$arrCate,$cate_id);
            }
        }

    /**
     * 条数
     * @param Request $request
     * @return float
     */
    public function shopCount(Request $request){
        $num=6;
        //获取分类id
        $cate_id=$request->input('cate_id');
        if(!empty($cate_id)){
            $arrIds=DB::table('category')->select('cate_id')->where('pid',0)->get();
            $this->get($cate_id);
        }
        $cate_id=self::$arrCate;
        //获取搜索信息
        $search=$request->input('search','');
        $where=[
            'goods_show'=>1
        ];
        //点击排序
        $order=$request->input('order','goods_id');
        $order_type=$request->input('order_type','asc');
        if($order=='goods_hot'||$order=='goods_new'){
            $where[$order]=1;
        }
        if(!empty($cate_id)){
            //查询分类下的商品
            $count=DB::table('goods')->where($where)
                ->whereIn('cate_id',$cate_id)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->count();
        }else{
            //查询所有商品
            $count=DB::table('goods')->where($where)
                ->where('goods_name','like',"%$search%")
                ->orderBy($order,$order_type)
                ->count();
        }
        $page=ceil($count/$num);
        echo $page;
        return $page;
    }
    //最新揭晓
    public function willshow(){
        return view('index.willshow');
    }
    //购物车
    public function shopcart(){
        return view('index.shopcart');
    }
}
