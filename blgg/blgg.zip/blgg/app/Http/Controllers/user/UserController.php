<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\models\shopModel;

class UserController extends Controller
{

    public function show(Request $request){
        $arr=$request->input('id');
//        echo $arr;
        $data=url('admin/add');
        echo $data;
//        exit;
        return redirect($data);
//        return view('user.usercontroller',['id'=>$arr]);
    }
    public function add(){
    }

    public function look(Request $request){
        //添加
//        $sql="insert into user set name='狗',age='19'";
//        $arr=DB::insert($sql);
//        print_r($arr);
        //修改
//        $sql="update user set name='王江涛' where id=1";
//        $arr=DB::update($sql);
//        var_dump($arr);
        //查询
//        $sql="select * from user";
//        $arr=DB::select($sql);
//        print_r($arr);
        //删除
//        $sql="delete from user where id=1";
//        $arr=DB::delete($sql);
//        print_r($arr);
    }
    /**
     * orm完成crud
     */
    public function orm(){
//        //查询
//        $arr=shopModel::all();
//        print_r($arr);
//        //添加
//        $name=array(
//            'name'=>'lisi',
//            'c_id'=>1,
//            'is_hot'=>2,
//            'is_show'=>2
//        );
//        $res=shopModel::insert($name);
//        echo $res;
        //删除
//        $id=15;
////        $res=shopModel::where('id','=',$id)->delete();
////        echo $res;
//        //修改
//        $id=14;
//        $arr=array(
//            'name'=>'zhansan'
//        );
//        $res=shopModel::where('id','=',$id)->update($arr);
//        echo $res;
    }
}
