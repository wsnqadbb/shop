<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class orderModel extends Model
{
    protected $table = 'order';
    public $timestamps = false;
}
